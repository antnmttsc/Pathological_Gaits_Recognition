import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf

import os

from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from tabulate import tabulate

import Utils.Constants as _c
from Utils.Preprocessing import load_and_preprocess_data_sk


def print_params(**params):
  print("\n=== LOSO CV Configuration ===")

  data_type = params.get('data_type', 'skeleton')
  select_x_subj = params.get('select_x_subj', None)

  keys_to_show = [
      'data_type','select_x_subj','joints','target_size','img_size',
      'clean_data','norm','crop_type','center_ft',
      'bidirectional','num_epochs_clf','patience_clf','lambda_l2','lr'
  ]

  for key in keys_to_show:
    if (data_type!='foot') and (key in ['center_ft','img_size']):
      continue
    if (data_type=='foot') and (key in ['joints','target_size','clean_data','crop_type','bidirectional','lambda_l2']):
      continue
    if (key == 'select_x_subj') and (select_x_subj is None):
      continue
    if key in params:
      print(f"{key:18}: {params[key]}")

  print("=============================\n")

def print_params_AE(**params):
  print("\n=== LOSO CV Configuration ===")

  select_x_subj = params.get('select_x_subj', None)

  keys_to_show = ['select_x_subj', 'num_epochs_clf','patience_clf',
                  'code_size','layer_type','num_epochs_AE','patience_AE', 'lr']

  for key in keys_to_show:
    if key in params:
      if (key=='select_x_subj') and (select_x_subj is not None):
        print(f"{key:18}: {select_x_subj}")
      else:
        print(f"{key:18}: {params[key]}")

  print("=============================\n")

def count_chunks(file_path, joints, clean_data, norm, target_size):
  data = load_and_preprocess_data_sk(file_path, joints, clean_data, norm)  # oppure speed
  noise_time_begin = int(data.shape[0] / 2) - 20
  noise_time_end = 10
  usable_len = data.shape[0] - noise_time_end - noise_time_begin
  return usable_len // target_size

def plot_history(history, subject:str):

  fig, axs = plt.subplots(1, 2, figsize=(12, 5))

  # loss
  axs[0].plot(history.history['loss'], label='Train loss')
  axs[0].plot(history.history['val_loss'], label='Val loss')
  axs[0].legend()
  axs[0].set_xlabel('Epoch')
  axs[0].set_ylabel('Loss')
  axs[0].set_title(f'Loss vs Epoch - {subject.capitalize()}')

  # accuracy
  axs[1].plot(history.history['accuracy'], label='Train accuracy')
  axs[1].plot(history.history['val_accuracy'], label='Val accuracy')
  axs[1].legend()
  axs[1].set_xlabel('Epoch')
  axs[1].set_ylabel('Accuracy')
  axs[1].set_title(f'Accuracy vs Epoch - {subject.capitalize()}')

  plt.tight_layout()
  plt.show()

def plot_history_AE(history, subject:str):

  plt.plot(history.history['mse'], label='Train MSE')
  plt.plot(history.history['val_mse'], label='Val MSE')
  plt.xlabel('Epoch')
  plt.ylabel('Mean Squared Error')
  plt.title(f'MSE vs Epoch - {subject.capitalize()}')
  
  plt.tight_layout()
  plt.show()

def print_time_info(subject, history_data, delta_time_data):

  print(f'Model Training Time: {delta_time_data:.2f} seconds')
  print(f"Number of epochs used for {subject}: {len(history_data.history['loss'])}")
  print(f"Time per epoch: {delta_time_data / len(history_data.history['loss']):.2f} seconds\n")

def remove_cache_from_drive(cache_data:str, data_dir:str):

  cache_data_path0 = os.path.join(os.path.dirname(data_dir), cache_data+'.index')
  cache_data_path1 = os.path.join(os.path.dirname(data_dir), cache_data+'.data-00000-of-00001')

  os.remove(cache_data_path0) if os.path.exists(cache_data_path0) else print(f"File {cache_data_path0} not found")
  os.remove(cache_data_path1) if os.path.exists(cache_data_path1) else print(f"File {cache_data_path1} not found")

def compute_metrics(
  model:tf.keras.Model,
  reference_df:pd.DataFrame,
  dataset:tf.data.Dataset,
  steps:int,
  subject:str=None,
  verbose:bool=True,
):
  # get the true labels
  y_true = reference_df['label'].values
  # get model's predictions
  preds = model.predict(dataset, steps=steps, verbose=0)[:len(y_true)].squeeze()
  y_pred = np.argmax(preds, axis=1)

  # overall accuracy
  accuracy = accuracy_score(y_true, y_pred)
  if verbose:
    print(f"\nValidation Accuracy: {accuracy:.2f}\n")

  # classification report
  labels = list(_c.convrt_gait_dict.keys())
  report_dict = classification_report(y_true, y_pred,
                                      zero_division=0,
                                      target_names=labels, 
                                      output_dict=True)
  df_report = pd.DataFrame(report_dict).transpose()
  if verbose:
    print("Classification Report:\n")
    print(df_report)
    print('\n')
  
  # plot confusion amtrix
  cm = confusion_matrix(y_true, y_pred)
  if verbose:
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=labels, yticklabels=labels)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title(f'Confusion Matrix - {subject.capitalize()}')
    plt.tight_layout()
    plt.show()

  return cm, df_report, accuracy

# FUSION MODEL LOSO CV UTILS

def print_time_info_fus(
  subject: str, 
  results: dict, 
  data_types_to_include: list
):
  data_types_to_include = data_types_to_include + ['fusion']
  
  table = []
  headers = ["Data Type", "Training Time (s)", "Epochs", "Time/Epoch (s)"]

  for data_type in data_types_to_include:
    delta_time_data = results[data_type]['dict_times'][subject]
    numb_epochs = len(results[data_type]['dict_history'][subject].history['loss'])
    time_per_epoch = delta_time_data / numb_epochs

    table.append([
      data_type.capitalize(),
      f"{delta_time_data:.2f}",
      numb_epochs,
      f"{time_per_epoch:.2f}"
    ])
  
  print('\n-- Time Info --\n')
  print(tabulate(table, headers=headers, tablefmt="grid"))

def plot_history_fus(
  results: dict, 
  subject: str, 
  data_types_to_include: list
):
  print('\n-- Models History --\n')

  data_types_to_include = data_types_to_include + ['fusion']
  numb_subplots = len(data_types_to_include)
  
  fig, axs = plt.subplots(numb_subplots, 2, figsize=(12, 4 * numb_subplots))
  
  for i, data_type in enumerate(data_types_to_include):
    history = results[data_type]['dict_history'][subject].history
    
    # Left plot for Loss
    axs[i, 0].plot(history['loss'], label='Train loss')
    axs[i, 0].plot(history['val_loss'], label='Val loss')
    axs[i, 0].set_xlabel('Epoch')
    axs[i, 0].set_ylabel('Loss')
    axs[i, 0].set_title(f'{data_type.capitalize()} Model Loss')
    axs[i, 0].legend()
    
    # Right plot for Accuracy
    if 'accuracy' in history:
      train_acc = history['accuracy']
      val_acc = history['val_accuracy']
    else:
      train_acc = val_acc = None
    
    if train_acc is not None and val_acc is not None:
      axs[i, 1].plot(train_acc, label='Train accuracy')
      axs[i, 1].plot(val_acc, label='Val accuracy')
      axs[i, 1].set_xlabel('Epoch')
      axs[i, 1].set_ylabel('Accuracy')
      axs[i, 1].set_title(f'{data_type.capitalize()} Model Accuracy')
      axs[i, 1].legend()
    else:
      axs[i, 1].text(0.5, 0.5, 'Accuracy data not found', ha='center', va='center')
      axs[i, 1].set_axis_off()
  
  fig.tight_layout()
  plt.show()

def compute_metrics_fus(
  model:tf.keras.Model,
  reference_df:pd.DataFrame,
  dataset:tf.data.Dataset,
  steps:int,
):
  # get the true labels
  y_true = reference_df['label'].values
  # get model's predictions
  preds = model.predict(dataset, steps=steps, verbose=0)[:len(y_true)].squeeze()
  y_pred = np.argmax(preds, axis=1)
  # overall accuracy
  accuracy = accuracy_score(y_true, y_pred)
  # classification report
  labels = list(_c.convrt_gait_dict.keys())
  report_dict = classification_report(y_true, y_pred,
                                      zero_division=0,
                                      target_names=labels, 
                                      output_dict=True)
  df_report = pd.DataFrame(report_dict).transpose()
  cm = confusion_matrix(y_true, y_pred)

  return cm, df_report, accuracy

def plot_metrics_fus(
    results:dict,
    subject:str,
    data_types_to_include:list,
    labels:list=list(_c.convrt_gait_dict.keys())
):
  print('\n-- Confusion Matrices --\n')
  data_types_to_include = data_types_to_include + ['fusion']

  fig, axs = plt.subplots(2, 2, figsize=(12, 10))
  axs = axs.flatten()
  
  # plot cm
  for idx, data_type in enumerate(data_types_to_include):
    cm_tmp = results[data_type]['dict_cm'][subject]
    
    sns.heatmap(cm_tmp, annot=True, fmt='d', cmap='Blues',
                xticklabels=labels, yticklabels=labels, ax=axs[idx])
    axs[idx].set_xlabel('Predicted')
    axs[idx].set_ylabel('True')
    axs[idx].set_title(f'{data_type.capitalize()} Model Confusion Matrix - {subject.capitalize()}')
  
  # clear any empty subplots
  for empty_idx in range(len(data_types_to_include), 4):
    axs[empty_idx].axis('off')
  
  fig.tight_layout()
  plt.show()
  
  # print clf rep and acc
  print('\n -- Classification Reports --')
  for data_type in data_types_to_include:
    df_report = results[data_type]['dict_clf_rep'][subject]
    avg_acc = results[data_type]['dict_acc'][subject]

    print(f"{data_type.capitalize()} Model Classification Report:\n")
    print(df_report)
    print('\n')
    print(f"{data_type.capitalize()} Model Accuracy: {avg_acc:.2f}\n")

