import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from matplotlib.lines import Line2D

import Utils.Constants as _c

def merge_results(res1:dict, res2:dict):
  merged = {}
  for key in res1.keys():
    merged[key] = {**res1[key], **res2[key]}
  return merged

def merge_loso_results(results_a:dict, results_b:dict):
  merged_results = {}

  for data_type in set(results_a.keys()).union(results_b.keys()):
    merged_results[data_type] = {}

    dict_a = results_a.get(data_type, {})
    dict_b = results_b.get(data_type, {})

    for metric_key in set(dict_a.keys()).union(dict_b.keys()):
      merged_results[data_type][metric_key] = {}

      values_a = dict_a.get(metric_key, {})
      values_b = dict_b.get(metric_key, {})

      merged_results[data_type][metric_key].update(values_a)
      merged_results[data_type][metric_key].update(values_b)

  return merged_results

def print_overall_time(results:dict, clf_or_ae:str='clf', which_model:str=None):

  if clf_or_ae == 'clf':
    model_times = results[which_model]['dict_times'] if which_model else results['dict_times']
    model_hist = results[which_model]['dict_history'] if which_model else results['dict_history']
  else:
    model_times = results['dict_times_AE']
    model_hist = results['dict_history_AE']

  model_epochs = {subject: len(history.history['loss']) \
                for subject, history in model_hist.items()}

  time_per_epoch_per_subject = [model_times[subject] / model_epochs[subject] \
                                for subject in model_times if model_epochs[subject] > 0]

  total_time = sum(model_times.values())
  mean_time = np.mean(list(model_times.values()))
  mean_time_per_epoch = np.mean(time_per_epoch_per_subject)

  model = 'Classifier' if clf_or_ae == 'clf' else 'Autoencoder'
  print(f"Total {model} Training Time: {total_time:.2f} s")
  print(f"Mean {model} Training Time per Subject: {mean_time:.2f} s")
  print(f"Mean {model} Training Time per Epoch: {mean_time_per_epoch:.2f} s")

def print_overall_epochs(results:dict, clf_or_ae:str='clf', which_model:str=None):

  if clf_or_ae == 'clf':
    ref_dict = results[which_model]['dict_history'] if which_model else results['dict_history']
  else:
    ref_dict = results['dict_history_AE']

  epochs_per_subject = {subject: len(history.history['loss']) \
                        for subject, history in ref_dict.items()}

  sorted_subjects = sorted(epochs_per_subject.keys(), key=lambda x: int(x.replace('subject', '')))
  epochs_ts = [epochs_per_subject[subj] for subj in sorted_subjects]

  plt.plot(range(1,len(sorted_subjects)+1), epochs_ts, marker='o', linestyle='-')
  plt.title("Epochs per Subject")
  plt.xlabel("Subject Index")
  plt.ylabel("Epochs")
  plt.grid(True)
  plt.tight_layout()
  plt.show()

def print_overall_cm(results:dict, which_model:str=None, labels:list=list(_c.convrt_gait_dict.keys())):

  results_tmp = results[which_model]['dict_cm'] if which_model else results['dict_cm']
  all_cm = sum(results_tmp.values())
  
  sns.heatmap(all_cm, annot=True, fmt='d', cmap='Blues',
              xticklabels=labels, yticklabels=labels)
  plt.title(f"Combined Confusion Matrix")
  plt.xlabel("Predicted")
  plt.ylabel("True")
  plt.tight_layout()
  plt.show()

def print_overall_clf_report(
  results:dict,
  which_model:str=None,
  class_names:list=['Normal', 'Antalgic', 'Stiff-legged', 'Lurching', 'Steppage', 'Trendelenburg']
):

  results_tmp = results[which_model]['dict_cm'] if which_model else results['dict_cm']
  cm = sum(results_tmp.values())

  headers = ["Class", "Accuracy", "Precision", "Recall", "Specificity"]
  row_format = "{:<15} {:>10} {:>10} {:>10} {:>12}"
  print(row_format.format(*headers))
  print("-" * 60)

  total_precision = []
  total_recall = []
  total_specificity = []

  for classe in range(cm.shape[0]):
    FP = cm[:, classe].sum() - cm[classe, classe]
    FN = cm[classe, :].sum() - cm[classe, classe]
    TP = cm[classe, classe]
    TN = cm.sum() - (FP + FN + TP)

    acc = (TP + TN) / (FP+ FN + TP + TN)
    precision = TP / (TP + FP)
    recall = TP / (TP + FN)
    specificity = TN / (TN + FP)

    total_precision.append(precision)
    total_recall.append(recall)
    total_specificity.append(specificity)

    print(row_format.format(
            class_names[classe],
            f"{acc:.4f}",
            f"{precision:.4f}",
            f"{recall:.4f}",
            f"{specificity:.4f}"
        ))
    
  total_acc = cm.diagonal().sum() / cm.sum()
  print("-" * 60)
  print(row_format.format(
        "Average",
        f"{np.mean(total_acc):.4f}",
        f"{np.mean(total_precision):.4f}",
        f"{np.mean(total_recall):.4f}",
        f"{np.mean(total_specificity):.4f}"
    ))
  
def print_overall_accuracies(results:dict, which_model:str=None):

  results_tmp = results[which_model]['dict_acc'] if which_model else results['dict_acc']
  acc_per_subject = {subject: acc for subject, acc in results_tmp.items()}

  sorted_subjects = sorted(acc_per_subject.keys(), key=lambda x: int(x.replace('subject', '')))
  acc_ts = [acc_per_subject[subj] for subj in sorted_subjects]

  plt.plot(range(1,len(sorted_subjects)+1), acc_ts, marker='o', linestyle='-')
  plt.title("Validation Accuracy per Subject")
  plt.xlabel("Subject Index")
  plt.ylabel("Validation Accuracy")
  plt.grid(True)
  plt.tight_layout()
  plt.show()

def print_overall_history(results:dict, which_model:str=None):

  dict_history = results[which_model]['dict_history'] if which_model else results['dict_history']
  max_epochs = max(len(history.history['loss']) for history in dict_history.values())

  sum_loss = np.zeros(max_epochs)
  sum_val_loss = np.zeros(max_epochs)
  sum_acc = np.zeros(max_epochs)
  sum_val_acc = np.zeros(max_epochs)
  count_per_epoch = np.zeros(max_epochs)

  fig, axs = plt.subplots(1, 2)

  for history in dict_history.values():
    epochs = len(history.history['loss'])

    sum_loss[:epochs] += history.history['loss']
    sum_val_loss[:epochs] += history.history['val_loss']
    sum_acc[:epochs] += history.history['accuracy']
    sum_val_acc[:epochs] += history.history['val_accuracy']
    count_per_epoch[:epochs] += 1

    # plot each history
    axs[0].plot(history.history['loss'], color='blue', alpha=0.3, linewidth=1)
    axs[0].plot(history.history['val_loss'], color='orange', alpha=0.3, linewidth=1)
    axs[1].plot(history.history['accuracy'], color='blue', alpha=0.3, linewidth=1)
    axs[1].plot(history.history['val_accuracy'], color='orange', alpha=0.3, linewidth=1)

  # averages
  avg_loss = sum_loss / count_per_epoch
  avg_val_loss = sum_val_loss / count_per_epoch
  avg_acc = sum_acc / count_per_epoch
  avg_val_acc = sum_val_acc / count_per_epoch

  # plot avg history
  axs[0].plot(avg_loss, color='blue', linewidth=2.5, label='Average Train Loss')
  axs[0].plot(avg_val_loss, color='orange', linewidth=2.5, label='Average Val Loss')
  axs[0].set_xlabel('Epoch')
  axs[0].set_ylabel('Loss')
  axs[0].set_title('Average Loss vs Epoch')

  axs[1].plot(avg_acc, color='blue', linewidth=2.5, label='Average Train Accuracy')
  axs[1].plot(avg_val_acc, color='orange', linewidth=2.5, label='Average Val Accuracy')
  axs[1].set_xlabel('Epoch')
  axs[1].set_ylabel('Accuracy')
  axs[1].set_title('Average Accuracy vs Epoch')

  thin_train = Line2D([0], [0], color='blue', linewidth=1, alpha=0.3, label='Train per Subject')
  thin_val = Line2D([0], [0], color='orange', linewidth=1, alpha=0.3, label='Val per Subject')
  thick_train = Line2D([0], [0], color='blue', linewidth=2.5, label='Average Train')
  thick_val = Line2D([0], [0], color='orange', linewidth=2.5, label='Average Val')
  axs[0].legend(handles=[thin_train, thin_val, thick_train, thick_val], fontsize=10)
  axs[1].legend(handles=[thin_train, thin_val, thick_train, thick_val], fontsize=10)

  plt.tight_layout()
  plt.show()

def print_overall_history_AE(results:dict):
    dict_history = results['dict_history_AE']
    max_epochs = max(len(history.history['loss']) for history in dict_history.values())

    sum_loss = np.zeros(max_epochs)
    sum_val_loss = np.zeros(max_epochs)
    count_per_epoch = np.zeros(max_epochs)

    fig, ax = plt.subplots()

    for history in dict_history.values():
        epochs = len(history.history['loss'])

        sum_loss[:epochs] += history.history['loss']
        sum_val_loss[:epochs] += history.history['val_loss']
        count_per_epoch[:epochs] += 1

        ax.plot(history.history['loss'], color='blue', alpha=0.3, linewidth=1)
        ax.plot(history.history['val_loss'], color='orange', alpha=0.3, linewidth=1)

    avg_loss = sum_loss / count_per_epoch
    avg_val_loss = sum_val_loss / count_per_epoch

    ax.plot(avg_loss, color='blue', linewidth=2.5, label='Average Train Loss')
    ax.plot(avg_val_loss, color='orange', linewidth=2.5, label='Average Val Loss')

    ax.set_xlabel('Epoch')
    ax.set_ylabel('Loss')
    ax.set_title('Average Loss vs Epoch')

    thin_train = Line2D([0], [0], color='blue', linewidth=1, alpha=0.3, label='Train per Subject')
    thin_val = Line2D([0], [0], color='orange', linewidth=1, alpha=0.3, label='Val per Subject')
    thick_train = Line2D([0], [0], color='blue', linewidth=2.5, label='Average Train')
    thick_val = Line2D([0], [0], color='orange', linewidth=2.5, label='Average Val')

    ax.legend(handles=[thin_train, thin_val, thick_train, thick_val], fontsize=10)

    plt.tight_layout()
    plt.show()
    
def print_overall_max_gpu_memory_usage(results:dict, clf_or_ae:str='clf', which_model:str=None):

  if clf_or_ae == 'clf':
    dict_memory = results[which_model]['dict_memory'] if which_model else results['dict_memory']
  else:
    dict_memory = results['dict_memory_AE']
  
  all_peak_values = []

  for mem_log in dict_memory.values():
    peak_gb = [mem_log[ep]['peak_gb'] for ep in sorted(mem_log.keys())]
    all_peak_values.extend(peak_gb)

  max_peak = max(all_peak_values)
  print(f'Max Peak GPU Memory Usage: {max_peak:.2f} GB')

def show_multiple_accuracies(results: dict, models: list):

  print(f"{'Model':<10} {'Avg Accuracy':>15}")
  print("-" * 20)
  for data_type in models:
      acc_all_subj = [results[data_type]['dict_acc'][subj] for subj in results[data_type]['dict_acc']]
      avg_acc = sum(acc_all_subj) / len(acc_all_subj)
      print(f"{data_type:<10} {avg_acc:>18.4f}")
  print('\n\n')

  plt.figure()

  color_cycle = plt.rcParams['axes.prop_cycle'].by_key()['color']  # Use matplotlib default color cycle

  for idx, model in enumerate(models):
    results_tmp = results[model]['dict_acc']
    acc_per_subject = {subject: acc for subject, acc in results_tmp.items()}
    sorted_subjects = sorted(acc_per_subject.keys(), key=lambda x: int(x.replace('subject', '')))
    acc_ts = [acc_per_subject[subj] for subj in sorted_subjects]

    color = color_cycle[idx % len(color_cycle)]

    plt.plot(range(1, len(sorted_subjects) + 1), acc_ts,
             marker='o', linestyle='-', color=color, label=model)

    mean_acc = np.mean(acc_ts)
    plt.axhline(mean_acc,linestyle='--',linewidth=1.5,color=color,label=None)

  plt.title("Validation Accuracy per Subject")
  plt.xlabel("Subject Index")
  plt.ylabel("Validation Accuracy")
  plt.grid(True)
  plt.legend(title="Model Type")
  plt.tight_layout()
  plt.show()

