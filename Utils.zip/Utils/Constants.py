left_joints = [4,5,6,7,8,9,10,18,19,20,21,28,29]
right_joints = [11,12,13,14,15,16,17,22,23,24,25,30,31]

convrt_gait_dict = {'normal': 0,
                    'antalgic': 1,
                    'stiff-legged': 2,
                    'lurching': 3,
                    'steppage': 4,
                    'trendelenburg': 5}

reversed_convrt_gait_dict = {v: k for k, v in convrt_gait_dict.items()} 

all_joints = list(range(0,32))
joints_to_include = [0,1,2,3,4,11,18,19,20,21,22,23,24,25]

joint_names = [
    'Spine base', 'Mid-spine', 'Spine shoulder', 'Neck', 'Left clavicle', 'Left shoulder', 'Left elbow',
    'Left wrist', 'Left hand', 'Left hand tip', 'Left thumb', 'Right clavicle', 'Right shoulder',
    'Right elbow', 'Right wrist', 'Right hand', 'Right hand tip', 'Right thumb', 'Left hip', 'Left knee',
    'Left ankle', 'Left foot', 'Right hip', 'Right knee', 'Right ankle', 'Right foot', 'Head',
    'Nose', 'Left eye', 'Left ear', 'Right eye', 'Right ear'
]

connections = [
    ('Spine base', 'Mid-spine'), ('Spine base', 'Right hip'), ('Spine base', 'Left hip'),
    ('Left hip', 'Left knee'), ('Right hip', 'Right knee'),
    ('Right knee', 'Right ankle'), ('Left knee', 'Left ankle'),
    ('Right ankle', 'Right foot'), ('Left ankle', 'Left foot'),
    ('Mid-spine', 'Spine shoulder'), ('Spine shoulder', 'Neck'),
    ('Spine shoulder', 'Left clavicle'), ('Spine shoulder', 'Right clavicle'),
    ('Left clavicle', 'Left shoulder'), ('Right clavicle', 'Right shoulder'),
    ('Left shoulder', 'Left elbow'), ('Right shoulder', 'Right elbow'),
    ('Left elbow', 'Left wrist'), ('Right elbow', 'Right wrist'),
    ('Left wrist', 'Left hand'), ('Left wrist', 'Left thumb'),
    ('Right wrist', 'Right hand'), ('Right wrist', 'Right thumb'),
    ('Left hand', 'Left hand tip'), ('Right hand', 'Right hand tip'),
    ('Neck', 'Head'), ('Head', 'Nose'), ('Head', 'Left eye'),
    ('Head', 'Right eye'), ('Head', 'Left ear'), ('Head', 'Right ear')
]

