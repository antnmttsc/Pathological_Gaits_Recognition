import numpy as np
import pandas as pd
import tensorflow as tf

import os

import Utils.Constants as _c

#####################
# DATA AUGMENTATION # 
#####################

def swap_left_right_joints(
  data:pd.DataFrame,
  left_joints:list=_c.left_joints,
  right_joints:list=_c.right_joints,
) -> pd.DataFrame:
  """
  This function takes a pd.DataFrame containing skeleton joint coordinates
  (with each joint represented by 3 consecutive columns for x, y, z) and
  swaps the values between corresponding left and right joints (manually inserted based on kinect documentation).
  """
  swapped_data = data.copy()

  for l_joint, r_joint in zip(left_joints, right_joints):
    l_slice = slice(l_joint*3+1, l_joint*3+4) # +1 bc of the first column w time info
    r_slice = slice(r_joint*3+1, r_joint*3+4)

    tmp = swapped_data.iloc[:, l_slice].values
    swapped_data.iloc[:, l_slice] = swapped_data.iloc[:, r_slice].values
    swapped_data.iloc[:, r_slice] = tmp

  return swapped_data

def flip_data(data:pd.DataFrame) -> pd.DataFrame:
  '''
  Horizontally flip the input foot pressure data. 
  '''
  return pd.DataFrame(np.fliplr(data))

#################
# CREATE LABELS #
#################

def create_reference_df(
    base_dir:str='/content/data',
    convrt_gait_dict:dict=_c.convrt_gait_dict,
) -> pd.DataFrame:
  """
  Create a reference DataFrame indexing original and augmented gait trial data.

  Main steps:
  - Iterates through each subject, gait type, and trial in the dataset.
  - Loads skeleton and foot pressure data.
  - Applies augmentation:
      * Swaps left/right joints in skeleton data.
      * Flips foot pressure images horizontally.
  - Saves augmented files in a new subfolder with '_flipped' suffix.
  - Adds both original and augmented entries to the reference DataFrame.

  Parameters:
  - base_dir (str): Path to the dataset root.
  - convrt_gait_dict (dict): Mapping from gait labels to numeric codes.

  Returns:
  - pd.DataFrame: A reference DataFrame with trial paths as index and columns:
      * 'label': Numeric gait type (using convrt_gait_dict to convert names).
      * 'subject': Subject number.
  """

  reference_df = pd.DataFrame(columns=['label', 'subject'])

  for subject in os.listdir(base_dir): # for each subject
    subject_dir = os.path.join(base_dir, subject)

    if not os.path.isdir(subject_dir):
      continue

    for gait in os.listdir(subject_dir): # for each gait
      gait_dir = os.path.join(subject_dir, gait)
      if not os.path.isdir(gait_dir):
        continue

      for trial in os.listdir(gait_dir): # for each trial
        trial_dir = os.path.join(gait_dir, trial)
        if not os.path.isdir(trial_dir):
          continue

        sk_data_path = os.path.join(trial_dir, 'skeleton.csv')
        ft_data_path = os.path.join(trial_dir, 'pressure.csv')
        if (not os.path.isfile(sk_data_path)) | (not os.path.isfile(ft_data_path)):
          continue

        reference_df.loc[trial_dir] = [convrt_gait_dict[gait], subject]

        # Data Augmentation
        flipped_data_sk = pd.read_csv(sk_data_path, header=None)
        flipped_data_sk = swap_left_right_joints(flipped_data_sk)

        flipped_data_ft = pd.read_csv(ft_data_path, header=None)
        flipped_data_ft = flip_data(flipped_data_ft)

        # save data into a new folder
        flipped_trial_dir = trial_dir + '_flipped'
        os.makedirs(flipped_trial_dir, exist_ok=True)

        flipped_data_sk.to_csv(os.path.join(flipped_trial_dir, 'skeleton.csv'), index=False, header=False)
        flipped_data_ft.to_csv(os.path.join(flipped_trial_dir, 'pressure.csv'), index=False, header=False)

        reference_df.loc[flipped_trial_dir] = [convrt_gait_dict[gait], subject]

  return reference_df

#############
# LOAD DATA #
#############

def compute_time_steps(data:pd.DataFrame):
  """
  Compute time deltas between frames, removing rows with zero time delta.
  Main steps:
  - pick time column (the first one) and convert to time object
  - compute the difference between each step and the sequential one
  - remove rows with time delta = 0
  - return cleaned data and time deltas
  """
  times = data[data.columns[0]].astype(str)
  times = times.apply(lambda x: x.replace('-', ''))
  times = pd.to_datetime(times, format='%Y%m%d_%H:%M:%S.%f')

  times_deltas = times.diff().dropna()
  times_deltas = times_deltas.dt.total_seconds()

  rows_to_drop = np.where(times_deltas.to_numpy() == 0)[0] + 1
  data = data.drop(index=rows_to_drop)

  times_deltas = times_deltas[times_deltas!=0]
  times_deltas = np.expand_dims(times_deltas, axis=1)

  return data, times_deltas

def compute_space_steps(data:pd.DataFrame):
  """
  Compute spatial deltas between joint positions frame-to-frame.
  Main steps:
  - drop time and NA columns
  - reshape data to (frames, joints, coordinates)
  - compute euclidean distance (between each frame and the sequential one)
  - return spatial deltas
  """
  data = data.drop([data.columns[0], data.columns[-1]], axis=1).copy()
  all_joints_position = data.to_numpy()

  num_joints = int(data.shape[1] / 3)
  all_joints_position = all_joints_position.reshape(-1, num_joints, 3)

  space_deltas = np.diff(all_joints_position, axis=0)
  space_deltas = np.linalg.norm(space_deltas, axis=2)

  return space_deltas

def load_data_sk(
  data_dir:str=None,
  clean_data:bool=True,
  deploy:bool=False,
):

  if isinstance(data_dir, bytes):
    data_dir = data_dir.decode()

  # load the csv file
  if deploy:
    data = pd.read_csv(data_dir, header=None)
  else:
    data = pd.read_csv(os.path.join(data_dir, 'skeleton.csv'), header=None)

  # remove rows with time diff = 0
  if clean_data:
    data, _ = compute_time_steps(data)

  # drop time and NA (last) columns
  data = data.drop([data.columns[0], data.columns[-1]], axis=1)

  # reshape data
  num_joints = int(data.shape[1] / 3)
  data = data.to_numpy().reshape((-1, num_joints, 3))

  # remove last row to match speed data size
  if clean_data:
    return data.squeeze()[:-1]
  else:
    return data.squeeze()

def load_data_speed(data_dir:str=None):

  if isinstance(data_dir, bytes):
    data_dir = data_dir.decode()

  data = pd.read_csv(os.path.join(data_dir, 'skeleton.csv'), header=None)

  # compute the difference in time between two consecutive frames
  data, times_deltas = compute_time_steps(data)

  # perform the same of above for the spatial dimension
  space_deltas = compute_space_steps(data)

  # compute the speed
  speed = space_deltas / times_deltas

  return speed

def load_data_ft(data_dir:str=None):

  if isinstance(data_dir, bytes):
    data_dir = data_dir.decode()

  data = pd.read_csv(os.path.join(data_dir, 'pressure.csv'), header=None).to_numpy()

  return data.squeeze()

#########################
# KEEP ONLY SOME JOINTS #
#########################

def remove_joints(
  data:np.ndarray, 
  joints_to_include:list=_c.all_joints, 
  is_speed:bool=False,
):
  
  return data[:, joints_to_include] if is_speed else data[:, joints_to_include, :]

##################
# NORMALIZE DATA #
##################

def norm_data_sk(data:np.ndarray):

  norm_factor_x = np.percentile(data[:, :, 0], 95) - np.percentile(data[:, :, 0], 5)
  norm_factor_y = np.percentile(data[:, :, 1], 95) - np.percentile(data[:, :, 1], 5)
  norm_factor_z = np.percentile(data[:, :, 2], 95) - np.percentile(data[:, :, 2], 5)

  data_norm = data.copy()

  data_norm[:, :, 0] = (data[:, :, 0] - np.percentile(data[:, :, 0], 5)) / norm_factor_x
  data_norm[:, :, 1] = (data[:, :, 1] - np.percentile(data[:, :, 1], 5)) / norm_factor_y
  data_norm[:, :, 2] = (data[:, :, 2] - np.percentile(data[:, :, 2], 5)) / norm_factor_z

  return data_norm

def norm_speed(data:np.ndarray):

  data_5th_percentile = np.percentile(data, 5, axis=0)
  data_95th_percentile = np.percentile(data, 95, axis=0)

  data_norm = (data - data_5th_percentile) / (data_95th_percentile - data_5th_percentile)

  return data_norm

def norm_data_ft(data:np.ndarray):
  
  data_norm = data/255.

  return data_norm

#############
# CROP DATA #
#############

def crop_data(
  data:np.ndarray, 
  target_size:int=50,
  crop_type:str='aggressive_center'
):
  '''
  Crops a sequence of data to a fixed length.
  '''
  if isinstance(crop_type, bytes):
    crop_type = crop_type.decode('utf-8')
  
  if crop_type=='top':
    data_crop = data[10:int(10+target_size)]
  
  elif crop_type=='bottom':
    data_without_noise = data[:-25, :]
    if data_without_noise.shape[0] < target_size:
      data_crop = data[-target_size:, :]
    else:
      data_crop = data_without_noise[-target_size:, :]
    
  elif crop_type=='40perc':
    numb40perc = int(data.shape[0] * 0.4)
    data_without_noise = data[numb40perc:, :]
    if data_without_noise.shape[0] < target_size:
      data_crop = data[-target_size:, :]
    else:
      data_crop = data_without_noise[:target_size, :]

  else: # center or random
    
    if 'aggressive' in crop_type:
      initial_noise, final_noise = int(data.shape[0]/2) - 20, 10

    else:
      initial_noise, final_noise = 10, 5
    
    start, end = initial_noise, data.shape[0] - final_noise

    data_without_noise = data[start:end, :]
    N = data_without_noise.shape[0]

    if 'center' in crop_type: # center crop
      initial_step = int((N / 2) - (target_size / 2))
    else: # random crop
      initial_step = np.random.randint(0, np.floor(N - target_size))

    data_crop = data_without_noise[initial_step:initial_step+target_size]

  if data_crop.shape[0]!=target_size:
    raise ValueError(f"Output data length is {data_crop.shape[0]} != {target_size=}")
  
  return data_crop

def extract_subseq(data, target_size:int):

  noise_time_begin = int(0.4*data.shape[0])
  noise_time_end = 10
  start = noise_time_begin
  end = data.shape[0] - noise_time_end
  data_crop = data[start:end, :]

  N = data_crop.shape[0]

  if target_size > N:
    raise ValueError(f"Target size {target_size} is larger than the cropped data size {N}")

  chunks = []
  for i in range(0, N - target_size + 1, target_size):
    chunks.append(data_crop[i:i + target_size])

  return np.stack(chunks).astype(np.float32)

###############
# CENTER DATA #
###############

def baricenter(data):
  # Compute the weighted average (barycenter) along each dimension
  y_barycenter = np.average(np.arange(data.shape[0]), weights=np.sum(data, axis=1))
  x_barycenter = np.average(np.arange(data.shape[1]), weights=np.sum(data, axis=0))

  # Compute the distances between each point and the barycenter
  shift_x = -(x_barycenter - data.shape[1]/2)
  shift_y = -(y_barycenter - data.shape[0]/2)

  # Shift the foot pressure matrix to be centered on the barycenter
  shifted_data = np.roll(data, int(shift_x), axis=1)
  shifted_data = np.roll(shifted_data, int(shift_y), axis=0)

  return shifted_data

############################
# LOAD AND PREPROCESS DATA #
############################

def load_and_preprocess_data_sk(
  path:str, 
  joints:list=list(range(0,32)), 
  clean_data:bool=True, 
  norm:bool=True,
  deploy:bool=False,
):
  if deploy:
    data = load_data_sk(path, clean_data, deploy=True)
  else:
    data = load_data_sk(path, clean_data)

  data = remove_joints(data, joints)

  if norm:
    data = norm_data_sk(data)

  data = data.reshape(len(data),-1)

  return data.astype(np.float32)

def load_and_preprocess_speed(
  path:str, 
  joints:list=None, 
  norm:bool=True
):

  data = load_data_speed(path)

  data = remove_joints(data, joints, is_speed=True)

  if norm:
    data = norm_speed(data)

  data = data.reshape(len(data),-1)

  return data.astype(np.float32)

def load_and_preprocess_data_ft(
  path:str, 
  norm:bool=True, 
  center:bool=True
):

  data = load_data_ft(path)

  if norm:
    data = norm_data_ft(data)

  if center:
    data = baricenter(data)

  return data.astype(np.float32)

######################
# DATASET DEFINITION #
######################

def create_dataset(
  reference_df:pd.DataFrame,
  data_type:str='skeleton',
  joints:list=list(range(0,32)),
  target_size:int=50,
  img_size:tuple=(128,48,1),
  clean_data:bool=True,
  norm:bool=True,
  crop_type:str=None,
  center_ft:bool=True,
  shuffle:bool=True,
  cache_file:str=None,
  batch_size:int=30,
):

  assert data_type in ('skeleton', 'speed', 'foot'), f"Invalid data_type: {data_type}"
  assert crop_type in ('top', 'bottom', '40perc', 'aggressive_center', 'aggressive_random', 'center', 'random', 'split_subsequence'), f"Invalid crop_type: {crop_type}"
  
  file_paths = list(reference_df.index)
  labels = reference_df['label']
  dataset = tf.data.Dataset.from_tensor_slices((file_paths, labels))

  ############################
  # LOAD AND PREPROCESS DATA #
  ############################
  if data_type=='skeleton':
    input_size = (target_size, len(joints)*3)
    py_func0 =  lambda file_path, label: (tf.numpy_function(load_and_preprocess_data_sk, [file_path, joints, clean_data, norm],
                                                           tf.float32), label)

  elif data_type=='speed':
    input_size = (target_size, len(joints))
    py_func0 =  lambda file_path, label: (tf.numpy_function(load_and_preprocess_speed, [file_path, joints, norm],
                                                           tf.float32), label)
  else: # data_type=='foot'
    input_size = img_size
    py_func0 =  lambda file_path, label: (tf.numpy_function(load_and_preprocess_data_ft, [file_path, norm, center_ft],
                                                           tf.float32), label)

  dataset = dataset.map(py_func0, num_parallel_calls=os.cpu_count())

  ########################################
  # SPLIT IN SUBSEQ OR ADJUST DIMENSIONS #
  ########################################
  if (data_type in ('skeleton', 'speed')) and (crop_type=='split_subsequence'):

    def map_and_split(data, label):
      def crop_wrapper(d):
        return extract_subseq(d, target_size)

      chunks = tf.py_function(func=crop_wrapper, inp=[data], Tout=tf.float32)
      chunks.set_shape([None, target_size, input_size[-1]])  # e.g.: (None, 50, 96)

      labels = tf.repeat(tf.expand_dims(label, 0), tf.shape(chunks)[0])
      return tf.data.Dataset.from_tensor_slices((chunks, labels))

    dataset = dataset.flat_map(map_and_split)

  if data_type=='foot': 
    dataset = dataset.map(lambda data, label: (tf.expand_dims(data, 2), label)) # input shape (128,48) --> (128,48,1)
    py_func1 = lambda data, label: (tf.ensure_shape(data, input_size), label)
    dataset = dataset.map(py_func1, num_parallel_calls=os.cpu_count())

  # cache
  if cache_file:
    dataset = dataset.cache(cache_file)

  # shuffle
  if shuffle:
    dataset = dataset.shuffle(buffer_size=len(file_paths))

  # repeat
  dataset = dataset.repeat()

  ########
  # CROP #
  ########
  if (data_type in ('skeleton', 'speed')) and (crop_type!='split_subsequence'):

    py_func1 = lambda data, label: (tf.ensure_shape(tf.numpy_function(crop_data, [data, target_size, crop_type],
                                                    tf.float32), input_size), label)
    dataset = dataset.map(py_func1, num_parallel_calls=os.cpu_count())
  
  # batch
  dataset = dataset.batch(batch_size)

  # prefetch
  dataset = dataset.prefetch(buffer_size=1)

  return dataset

def create_dataset_AE(
  reference_df:pd.DataFrame,
  train_or_valid:str='train',
  train_AE:bool=True,
  encoder_model:tf.keras.Model=None,
  shuffle:bool=True,
  cache_file:str=None,
  batch_size:int=30,
):

  file_paths = list(reference_df.index)
  labels = reference_df['label']
  dataset = tf.data.Dataset.from_tensor_slices((file_paths, labels))

  # now these variables keep fixed values
  joints = list(range(0,32)) # use all joints
  target_size = 50 
  input_size = (target_size, len(joints)*3)
  norm, clean_data = True, True

  # LOAD AND PREPROCESS DATA
  py_func0 =  lambda file_path, label: (tf.numpy_function(load_and_preprocess_data_sk, [file_path, joints, clean_data, norm],
                                                          tf.float32), label)
  dataset = dataset.map(py_func0, num_parallel_calls=os.cpu_count())

  # CROP
  if train_or_valid=='train':
    def map_and_split(data, label):
      def crop_wrapper(d):
        return extract_subseq(d, target_size)

      chunks = tf.py_function(func=crop_wrapper, inp=[data], Tout=tf.float32)
      chunks.set_shape([None, target_size, input_size[-1]])  # e.g.: (None, 50, 96)

      labels = tf.repeat(tf.expand_dims(label, 0), tf.shape(chunks)[0])
      return tf.data.Dataset.from_tensor_slices((chunks, labels))

    dataset = dataset.flat_map(map_and_split)

  else: # train_or_valid=='valid'
    py_func1 = lambda data, label: (tf.ensure_shape(tf.numpy_function(crop_data, [data, target_size, 'aggressive_center'],
                                                    tf.float32), input_size), label)
    dataset = dataset.map(py_func1, num_parallel_calls=os.cpu_count())

  # ARE WE TRAINING THE AE OR USING IT TO EXTRACT FEATURES?
  if train_AE:
    py_func2 = lambda data, label: (data, data)
    dataset = dataset.map(py_func2, num_parallel_calls=os.cpu_count())

  else:
    def encode_sample(data, label):
      data = tf.expand_dims(data, 0)
      encoded = encoder_model(data, training=False)
      encoded = tf.squeeze(encoded, axis=0)
      return encoded, label
    
    dataset = dataset.map(encode_sample, num_parallel_calls=os.cpu_count()) 

  # cache
  if cache_file:
    dataset = dataset.cache(cache_file)

  # shuffle
  if shuffle:
    dataset = dataset.shuffle(buffer_size=len(file_paths))

  # repeat
  dataset = dataset.repeat()
  
  # batch
  dataset = dataset.batch(batch_size)

  # prefetch
  dataset = dataset.prefetch(buffer_size=1)

  return dataset

def create_fusion_dataset(
  reference_df:pd.DataFrame,
  train_or_valid:str='train',
  data_types_to_include:list=['skeleton','speed','foot'],
  shuffle:bool=True,
  cache_file:str=None,
  batch_size:int=30,
):

  file_paths = list(reference_df.index)
  labels = reference_df['label'].tolist()

  dataset = tf.data.Dataset.from_tensor_slices((file_paths, labels))

  # these variables keep fixed values
  target_size = 50
  joints = [0,1,2,3,4,11,18,19,20,21,22,23,24,25]
  img_size = (128, 48, 1)
  clean_data, norm, center_ft = True, True, True

  # LOAD AND PREPROCESS DATA
  def load_raw_modalities(file_path, label, data_types_to_include=data_types_to_include):
    outputs = []

    if 'skeleton' in data_types_to_include:
      sk = tf.numpy_function(load_and_preprocess_data_sk, [file_path, joints, clean_data, norm], tf.float32)
      sk = tf.ensure_shape(sk, [None, len(joints)*3])
      outputs.append(sk)

    if 'speed' in data_types_to_include:
      sp = tf.numpy_function(load_and_preprocess_speed, [file_path, joints, norm], tf.float32)
      sp = tf.ensure_shape(sp, [None, len(joints)])
      outputs.append(sp)

    if 'foot' in data_types_to_include:
      ft = tf.numpy_function(load_and_preprocess_data_ft, [file_path, norm, center_ft], tf.float32)
      ft = tf.expand_dims(ft, axis=-1)
      ft = tf.ensure_shape(ft, img_size)
      outputs.append(ft)

    return tuple(outputs), label

  dataset = dataset.map(load_raw_modalities, num_parallel_calls=os.cpu_count())

  # FLAT MAP FOR EXTRACT_SUBSEQ OR CROP DATA
  if train_or_valid=='train':
    def extract_chunks(inputs, label):
      def chunk_wrapper(*args):
        chunks = []
        idx = 0
        if 'skeleton' in data_types_to_include:
          sk_chunks = extract_subseq(args[idx], target_size)
          chunks.append(sk_chunks)
          idx += 1
        if 'speed' in data_types_to_include:
          sp_chunks = extract_subseq(args[idx], target_size)
          chunks.append(sp_chunks)
          idx += 1
        if 'foot' in data_types_to_include:
          ft = args[idx]
          # repeat foot image for each skeleton/speed chunk
          ft = tf.expand_dims(ft, axis=0)
          num_chunks = tf.shape(chunks[0])[0]
          ft = tf.repeat(ft, repeats=num_chunks, axis=0)
          chunks.append(ft)

        return tuple(chunks)

      chunked = tf.py_function(func=chunk_wrapper, inp=inputs, Tout=[tf.float32]*len(inputs))
      for i, shape in enumerate(inputs):
        if isinstance(shape, tf.Tensor):
          if data_types_to_include[i] in ['skeleton', 'speed']:
            chunked[i].set_shape([None, target_size] + shape.shape[1:].as_list())
          else: # foot data
            chunked[i].set_shape([None] + shape.shape.as_list())

      labels_repeated = tf.repeat(tf.expand_dims(label, 0), tf.shape(chunked[0])[0])
      return tf.data.Dataset.from_tensor_slices((tuple(chunked), labels_repeated))

    dataset = dataset.flat_map(extract_chunks)
  
  else:  # train_or_valid=='valid'
    crop_type = 'aggressive_center'
    def crop_modalities(inputs, label):
      outputs = []
      idx = 0

      if 'skeleton' in data_types_to_include:
        sk = tf.numpy_function(crop_data, [inputs[idx], target_size, crop_type], tf.float32)
        sk = tf.ensure_shape(sk, (target_size, len(joints)*3))
        outputs.append(sk)
        idx += 1

      if 'speed' in data_types_to_include:
        sp = tf.numpy_function(crop_data, [inputs[idx], target_size, crop_type], tf.float32)
        sp = tf.ensure_shape(sp, (target_size, len(joints)))
        outputs.append(sp)
        idx += 1

      if 'foot' in data_types_to_include:
        ft = inputs[idx]
        outputs.append(ft)

      return tuple(outputs), label

    dataset = dataset.map(crop_modalities, num_parallel_calls=os.cpu_count())

  # cache
  if cache_file:
    dataset = dataset.cache(cache_file)

  # shuffle
  if shuffle:
    dataset = dataset.shuffle(buffer_size=len(file_paths))

  # repeat
  dataset = dataset.repeat()

  # batch
  dataset = dataset.batch(batch_size)

  # prefetch
  dataset = dataset.prefetch(buffer_size=1)

  return dataset
